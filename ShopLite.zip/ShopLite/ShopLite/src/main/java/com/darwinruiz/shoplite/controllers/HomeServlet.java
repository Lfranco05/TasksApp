package com.darwinruiz.shoplite.controllers;

import com.darwinruiz.shoplite.models.Product;
import com.darwinruiz.shoplite.repositories.ProductRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int page = 1;
        int size = 5; // Tamaño de página por defecto

        // Leer parámetros de paginación
        try {
            if (request.getParameter("page") != null) {
                page = Integer.parseInt(request.getParameter("page"));
            }
            if (request.getParameter("size") != null) {
                size = Integer.parseInt(request.getParameter("size"));
            }
        } catch (NumberFormatException e) {
            // Si hay error en los parámetros, usar valores por defecto
        }

        ProductRepository repo = new ProductRepository();
        List<Product> allProducts = repo.findAll();
        int total = allProducts.size();

        // Calcular índices de sublista
        int fromIndex = (page - 1) * size;
        int toIndex = Math.min(fromIndex + size, total);

        List<Product> items = allProducts.subList(fromIndex, toIndex);

        // Enviar datos a la vista
        request.setAttribute("items", items);
        request.setAttribute("page", page);
        request.setAttribute("size", size);
        request.setAttribute("total", total);

        request.getRequestDispatcher("/home.jsp").forward(request, response);
    }
}
