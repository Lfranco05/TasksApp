package com.darwinruiz.shoplite.controllers;

import com.darwinruiz.shoplite.models.Product;
import com.darwinruiz.shoplite.repositories.ProductRepository;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Requisito (POST): validar y crear un nuevo producto en memoria y redirigir a /home.
 */
@WebServlet("/admin")
public class AdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String priceStr = request.getParameter("price");

        boolean isValid = true;
        double price = 0;

        try {
            price = Double.parseDouble(priceStr);
            if (price <= 0) {
                isValid = false;
            }
        } catch (NumberFormatException e) {
            isValid = false;
        }

        if (name == null || name.trim().isEmpty()) {
            isValid = false;
        }

        if (isValid) {
            ProductRepository repo = new ProductRepository();
            int newId = repo.nextId();
            Product newProduct = new Product(newId, name, price);
            repo.save(newProduct);
            response.sendRedirect(request.getContextPath() + "/home");
        } else {
            response.sendRedirect(request.getContextPath() + "/admin?err=1");
        }
    }
}