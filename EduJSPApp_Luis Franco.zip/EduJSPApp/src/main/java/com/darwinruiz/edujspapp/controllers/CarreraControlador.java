package com.darwinruiz.edujspapp.controllers;

import com.darwinruiz.edujspapp.models.Carrera;
import com.darwinruiz.edujspapp.services.CarreraService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/carreras")
public class CarreraControlador extends HttpServlet {
    private CarreraService carreraService = new CarreraService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        switch (accion) {
            case "nuevo":
                // Ocultar menú en formulario nuevo
                request.setAttribute("mostrarMenu", false);
                request.getRequestDispatcher("views/carreras/formCarrera.jsp").forward(request, response);
                break;
            case "editar":
                int idEditar = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("carrera", carreraService.buscarPorId(idEditar));
                // Ocultar menú en formulario editar
                request.setAttribute("mostrarMenu", false);
                request.getRequestDispatcher("views/carreras/formCarrera.jsp").forward(request, response);
                break;
            case "eliminar":
                int idEliminar = Integer.parseInt(request.getParameter("id"));
                carreraService.eliminar(idEliminar);
                response.sendRedirect("carreras");
                break;
            default:
                request.setAttribute("lista", carreraService.listar());
                // Ocultar menú en listado (cambia a true si quieres mostrarlo en lista)
                request.setAttribute("mostrarMenu", false);
                request.getRequestDispatcher("views/carreras/listarCarreras.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");  // Muy importante para caracteres especiales

        String idStr = request.getParameter("id");
        int id = 0;
        try {
            id = (idStr != null && !idStr.isEmpty()) ? Integer.parseInt(idStr) : 0;
        } catch (NumberFormatException e) {
            id = 0;
        }

        String nombre = request.getParameter("nombre");
        String codigo = request.getParameter("codigo");
        String facultad = request.getParameter("facultad");
        String nivel = request.getParameter("nivel");
        String[] modalidadesArr = request.getParameterValues("modalidades");
        boolean estadoActiva = request.getParameter("estadoActiva") != null;
        String descripcion = request.getParameter("descripcion");

        Carrera carrera = new Carrera(id, nombre, codigo, facultad, nivel,
                (modalidadesArr != null) ? Arrays.asList(modalidadesArr) : new ArrayList<>(),
                estadoActiva, descripcion);

        if (id == 0) {
            carreraService.agregar(carrera);
        } else {
            carreraService.actualizar(carrera);
        }

        response.sendRedirect("carreras");
    }
}