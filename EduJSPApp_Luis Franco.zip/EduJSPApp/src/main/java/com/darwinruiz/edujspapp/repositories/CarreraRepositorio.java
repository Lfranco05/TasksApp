package com.darwinruiz.edujspapp.repositories;

import com.darwinruiz.edujspapp.models.Carrera;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CarreraRepositorio {
    private static List<Carrera> carreras = new ArrayList<>();
    private static int ultimoId = 1;

    static {
        carreras.add(new Carrera(ultimoId++, "Ingeniería en Sistemas", "SIS01", "Ingeniería",
                "Licenciatura", Arrays.asList("Presencial", "Virtual"), true,
                "Carrera enfocada en desarrollo de software y sistemas."));
    }

    public List<Carrera> obtenerTodos() {
        return carreras;
    }

    public Carrera obtenerPorId(int id) {
        return carreras.stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void agregar(Carrera carrera) {
        carrera.setId(ultimoId++);
        carreras.add(carrera);
    }

    public void actualizar(Carrera carrera) {
        Carrera existente = obtenerPorId(carrera.getId());
        if (existente != null) {
            existente.setNombre(carrera.getNombre());
            existente.setCodigo(carrera.getCodigo());
            existente.setFacultad(carrera.getFacultad());
            existente.setNivel(carrera.getNivel());
            existente.setModalidades(carrera.getModalidades());
            existente.setEstadoActiva(carrera.isEstadoActiva());
            existente.setDescripcion(carrera.getDescripcion());
        }
    }

    public void eliminar(int id) {
        carreras.removeIf(c -> c.getId() == id);
    }
}
