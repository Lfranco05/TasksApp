package com.darwinruiz.edujspapp.services;

import com.darwinruiz.edujspapp.models.Profesor;
import com.darwinruiz.edujspapp.repositories.ProfesorRepositorio;

import java.util.ArrayList;
import java.util.List;

public class ProfesorService {
    private final ProfesorRepositorio repositorio = new ProfesorRepositorio();

    public List<Profesor> obtenerTodos() {
        return repositorio.obtenerTodos();
    }

    public void registrar(Profesor profesor) {
        repositorio.guardar(profesor);
    }

    public Profesor buscarPorId(int id) {
        return repositorio.buscarPorId(id);
    }

    public void actualizar(Profesor profesor) {
        repositorio.actualizar(profesor);
    }

    public void eliminar(int id) {
        repositorio.eliminar(id);
    }
}
