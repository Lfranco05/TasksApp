package com.darwinruiz.edujspapp.services;

import com.darwinruiz.edujspapp.models.Carrera;
import com.darwinruiz.edujspapp.repositories.CarreraRepositorio;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class CarreraService {
    private static List<Carrera> listaCarreras = new ArrayList<>();
    private static int contadorId = 1;

    static {
        listaCarreras.add(new Carrera(contadorId++, "Ingeniería en Sistemas", "SIS01", "Ingeniería",
                "Licenciatura", Arrays.asList("Presencial", "Virtual"), true,
                "Carrera enfocada en el desarrollo de software y sistemas informáticos."));
    }

    public List<Carrera> listar() {
        return listaCarreras;
    }

    public Carrera buscarPorId(int id) {
        return listaCarreras.stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void agregar(Carrera carrera) {
        carrera.setId(contadorId++);
        listaCarreras.add(carrera);
    }

    public void actualizar(Carrera carrera) {
        Carrera existente = buscarPorId(carrera.getId());
        if (existente != null) {
            existente.setNombre(carrera.getNombre());
            existente.setCodigo(carrera.getCodigo());
            existente.setFacultad(carrera.getFacultad());
            existente.setNivel(carrera.getNivel());
            existente.setModalidades(carrera.getModalidades());
            existente.setEstadoActiva(carrera.isEstadoActiva());
            existente.setDescripcion(carrera.getDescripcion());
        }
    }

    public void eliminar(int id) {
        listaCarreras.removeIf(c -> c.getId() == id);
    }
}