package com.lfranco.calculadoraavanzada.Services;

public class ArithmeticService {
    public static double suma(double a, double b) { return a + b; }
    public static double resta(double a, double b) { return a - b; }
    public static double multiplicacion(double a, double b) { return a * b; }
    public static double division(double a, double b) { return a / b; }
}