package com.darwinruiz.shoplite.controllers;

import com.darwinruiz.shoplite.models.Product;
import com.darwinruiz.shoplite.repositories.ProductRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Requisito (POST): validar y crear un nuevo producto en memoria y redirigir a /home.
 */
@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
    private final ProductRepository repo = new ProductRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            req.getRequestDispatcher("/admin.jsp").forward(req, resp);
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String name = req.getParameter("name");
        String priceParam = req.getParameter("price");

        if (name == null || name.trim().isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/admin?err=1");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceParam);
        } catch (NumberFormatException e) {
            resp.sendRedirect(req.getContextPath() + "/admin?err=1");
            return;
        }

        if (price <= 0) {
            resp.sendRedirect(req.getContextPath() + "/admin?err=1");
            return;
        }

        // Obtener nuevo ID con tipo long
        long newId = repo.nextId();

        // Crear producto usando long para el ID (asegúrate que Product tiene constructor con long id)
        Product product = new Product(newId, name.trim(), price);

        // Usar add() para guardar producto
        repo.add(product);

        resp.sendRedirect(req.getContextPath() + "/home");
    }
}