package com.darwinruiz.shoplite.controllers;

import com.darwinruiz.shoplite.models.Product;
import com.darwinruiz.shoplite.repositories.ProductRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {
    private final ProductRepository repo = new ProductRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        List<Product> all = repo.findAll();

        int page = 1;
        int size = 10;

        try {
            String pageParam = req.getParameter("page");
            String sizeParam = req.getParameter("size");

            if (pageParam != null) page = Integer.parseInt(pageParam);
            if (sizeParam != null) size = Integer.parseInt(sizeParam);
        } catch (NumberFormatException e) {
            // Valores por defecto si parse falla
        }

        // Validar valores mínimos
        if (page < 1) page = 1;
        if (size < 1) size = 10;

        int total = all.size();

        // Calcular el máximo número de páginas disponibles
        int maxPage = (int) Math.ceil((double) total / size);
        if (page > maxPage) page = maxPage > 0 ? maxPage : 1;

        int fromIndex = (page - 1) * size;
        int toIndex = Math.min(fromIndex + size, total);

        List<Product> items;

        if (fromIndex >= total || fromIndex < 0) {
            items = List.of();
        } else {
            items = all.subList(fromIndex, toIndex);
        }

        req.setAttribute("items", items);
        req.setAttribute("page", page);
        req.setAttribute("size", size);
        req.setAttribute("total", total);

        try {
            req.getRequestDispatcher("/home.jsp").forward(req, resp);
        } catch (Exception e) {
            throw new IOException(e);
        }
    }
}
